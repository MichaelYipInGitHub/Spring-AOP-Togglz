package com.m.springboot;
	
	import org.springframework.stereotype.Service;
	
	import com.m.springboot.aop.MyAnnotation;
	import com.m.springboot.togglz.MyFeatures;
	
	
	
	@Service
	public class MyService {
		
		@MyAnnotation(value = MyFeatures.EMPLOYEE_MANAGEMENT_FEATURE)
		public String addSalary() throws Exception {
			System.out.println("加人工！");
			return "加人工！";
		}
	}
