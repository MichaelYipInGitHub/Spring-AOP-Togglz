package com.m.springboot;

import org.springframework.stereotype.Service;

import com.m.springboot.togglz.MyFeatures;



@Service
public class MyService {
	public String addSalary() throws Exception {
		if (MyFeatures.EMPLOYEE_MANAGEMENT_FEATURE.isActive()) {
		System.out.println("加人工！");
		return "加人工！";
		}else {
			return null;
		}
	}
}
