package com.m.springboot.togglz;

import java.io.File;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.togglz.core.Feature;
import org.togglz.core.manager.EnumBasedFeatureProvider;
import org.togglz.core.manager.TogglzConfig;
import org.togglz.core.repository.StateRepository;
import org.togglz.core.repository.file.FileBasedStateRepository;
import org.togglz.core.spi.FeatureProvider;
import org.togglz.core.user.UserProvider;
import org.togglz.servlet.user.ServletUserProvider;

@Configuration
public class ToggleConfiguration implements TogglzConfig {
 
    @Bean
    public FeatureProvider featureProvider() {
        return new EnumBasedFeatureProvider(MyFeatures.class);
    }

	@Override
	public Class<? extends Feature> getFeatureClass() {
		// TODO Auto-generated method stub
		return MyFeatures.class;
	}

	@Override
	public StateRepository getStateRepository() {
		// TODO Auto-generated method stub
		return new FileBasedStateRepository(new File("application.yml"));
	}

	@Override
	public UserProvider getUserProvider() {
		// TODO Auto-generated method stub
		return new ServletUserProvider(null);
	}
}