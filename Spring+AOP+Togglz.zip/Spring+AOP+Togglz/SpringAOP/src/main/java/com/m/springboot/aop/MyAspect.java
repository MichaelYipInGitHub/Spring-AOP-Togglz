package com.m.springboot.aop;

import java.lang.reflect.Method;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
 
@Aspect // 1：通过改注解声明一个切面
@Component // 2让切面称为spring管理的bean
public class MyAspect {
 
	
	//切面
	@Around("@annotation(com.m.springboot.aop.MyAnnotation)") //6:直接拦截方法名
    public Object   before(ProceedingJoinPoint joinPoint) throws Throwable{
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        System.out.println("方法规则式拦截,"+method.getName());
        return null;
//        return joinPoint.proceed();
 
    }
}
