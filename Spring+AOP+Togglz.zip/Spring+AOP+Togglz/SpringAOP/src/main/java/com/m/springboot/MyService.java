package com.m.springboot;

import org.springframework.stereotype.Service;

import com.m.springboot.aop.MyAnnotation;


@Service
public class MyService {
	
	@MyAnnotation(name = "addSalary!")
	public String addSalary() throws Exception {
		System.out.println("加人工！");
		return "加人工！";
	}
}
